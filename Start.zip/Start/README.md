Kaique Maia Reis Silva    RM 552112     
Pedro H A Guariente       RM 550301
Orlando Akio              RM 98067
David de Medeiro Junior   RM 551462